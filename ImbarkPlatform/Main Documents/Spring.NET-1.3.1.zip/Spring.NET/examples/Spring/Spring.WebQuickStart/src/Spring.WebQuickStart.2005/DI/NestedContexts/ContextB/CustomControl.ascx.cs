
public partial class DI_NestedContexts_ContextB_CustomControlB : System.Web.UI.UserControl
{
  private string _message;

  public string Message
  {
    get { return this._message; }
    set { this._message = value; }
  }
}
