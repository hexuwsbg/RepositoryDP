Step1 :
Use Spring.Aop programmatically

Step2 :
Use Spring.Aop within IoC container

Step3 :
Use Spring.NET convenience pointcuts (Match by method name)

Step4 :
Use Spring.NET convenience pointcuts (Match by attribute)

Step5 :
Create and use custom pointcuts

Step6 :
Use Introductions (mixins)

Step7 :
Use AutoProxy functionality