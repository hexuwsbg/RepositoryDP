
namespace Spring.TxQuickStart.Dao
{
    public interface IAccountDebitDao
    {
        void DebitAccount(float debitAmount);
    }
}
