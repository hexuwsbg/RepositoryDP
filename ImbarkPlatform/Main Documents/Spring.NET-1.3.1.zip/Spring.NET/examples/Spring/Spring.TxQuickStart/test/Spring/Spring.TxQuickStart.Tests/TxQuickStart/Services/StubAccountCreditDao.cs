using Spring.TxQuickStart.Dao;

namespace Spring.TxQuickStart.Services
{
    public class StubAccountCreditDao : IAccountCreditDao
    {
        public void CreateCredit(float creditAmount)
        {
            
        }
    }
}