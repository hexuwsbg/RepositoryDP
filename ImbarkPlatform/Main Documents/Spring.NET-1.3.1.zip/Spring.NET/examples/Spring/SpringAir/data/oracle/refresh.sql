connect springair/spring
@drop.sql
@create.sql
@populate.sql
commit;
