drop table t_reserved_seat;
drop table t_leg_seat;

drop table t_leg;
drop table t_reservation;
drop table t_flight;

drop table t_airport;
drop table t_aircraft_cabin_seat;
drop table t_aircraft;

drop table t_cabin_class;
drop table t_passenger;
